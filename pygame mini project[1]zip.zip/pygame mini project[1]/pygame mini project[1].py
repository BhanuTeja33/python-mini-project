import pygame, random

# Initialize pygame
pygame.init()
pygame.mixer.init()

# Load sound effects (adjust paths to your system)
flip_sound = pygame.mixer.Sound(r"C:\Users\velpu\Downloads\flip-switch-304548.mp3")
match_sound = pygame.mixer.Sound(r"C:\Users\velpu\Downloads\game-bonus-2-294436.mp3")
nomatch_sound = pygame.mixer.Sound(r"C:\Users\velpu\Downloads\censor-beep-1sec-8112.mp3")

# Constants
W, H = 600, 700
P = 10
FONT = pygame.font.SysFont(None, 40)
clock = pygame.time.Clock()
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("Memory Card Game")

# Level definitions
levels = [(4, 4), (4, 6), (6, 6)]  # Level 1 (16), Level 2 (24), Level 3 (36) — all even

current_level = 0

def init_level(rows, cols):
    global vals, cards, face, sel, win, win_t, t0, gs
    gs = (W - (cols + 1) * P) // cols
    vals = list(range((rows * cols) // 2)) * 2
    random.shuffle(vals)
    cards = [pygame.Rect(P + j * (gs + P), 100 + P + i * (gs + P), gs, gs)
             for i in range(rows) for j in range(cols)]
    face = [0] * len(cards)
    sel = []
    win = False
    t0 = pygame.time.get_ticks()

def choose_level():
    screen.fill((30, 30, 30))
    title = FONT.render("Select Level: 1, 2, or 3", True, (255, 255, 255))
    screen.blit(title, (W // 2 - title.get_width() // 2, 200))
    pygame.display.flip()
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_1: return 0
                if e.key == pygame.K_2: return 1
                if e.key == pygame.K_3: return 2

# Start with level 1
init_level(*levels[current_level])

# Game loop
running = True
while running:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and not win:
            if len(sel) < 2:
                for i, c in enumerate(cards):
                    if c.collidepoint(e.pos) and not face[i]:
                        face[i] = 1
                        sel.append(i)
                        flip_sound.play()
                        break

    if len(sel) == 2:
        pygame.time.delay(500)
        if vals[sel[0]] == vals[sel[1]]:
            match_sound.play()
        else:
            nomatch_sound.play()
            face[sel[0]] = face[sel[1]] = 0
        sel = []

    if not win and all(face):
        win = True
        win_t = pygame.time.get_ticks()

    screen.fill((0, 0, 0))
    for y in range(H):
        pygame.draw.line(screen, (0, 0, 50 + y // 10), (0, y), (W, y))

    for i, c in enumerate(cards):
        card_color = (200, 200, 200) if not face[i] else (100, 200, 100)
        shadow = c.copy(); shadow.x += 4; shadow.y += 4
        pygame.draw.rect(screen, (0, 0, 0), shadow, border_radius=12)
        pygame.draw.rect(screen, card_color, c, border_radius=12)
        pygame.draw.rect(screen, (50, 50, 50), c, 2, border_radius=12)
        if face[i]:
            txt = FONT.render(str(vals[i]), True, (0, 0, 0))
            screen.blit(txt, (c.x + (gs - txt.get_width()) // 2, c.y + (gs - txt.get_height()) // 2))

    if not win:
        txt = FONT.render(f"Level {current_level+1}  |  Time: {(pygame.time.get_ticks()-t0)//1000}s", True, (255, 255, 255))
    else:
        txt = FONT.render("You Win!", True, (255, 255, 255))
        if pygame.time.get_ticks() - win_t > 2000:
            current_level += 1
            if current_level >= len(levels):
                current_level = choose_level()
            init_level(*levels[current_level])
            continue

    screen.blit(txt, (W // 2 - txt.get_width() // 2, 30))
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
